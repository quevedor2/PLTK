## ------------------------------------------------------------------------
PLTK::genDemoData()

## ------------------------------------------------------------------------
PLTK::sigClusterBreakpoints(genDemoData(), 50)

## ------------------------------------------------------------------------
PLTK::sigBinBreakpoints(PLTK::genDemoData(), PLTK::bins)[['segs']][[1]]

## ------------------------------------------------------------------------
PLTK::sigBinBreakpoints(PLTK::genDemoData(), PLTK::bins)[['bins']]

## ------------------------------------------------------------------------
repetitive.sequence <- c(rep(1,5), rep(2,5), rep(3,5))
rle.x <- PLTK::getRleIdx(repetitive.sequence)
str(rle.x)

 
repetitive.sequence[rle.x$start.idx[2]:rle.x$end.idx[2]]

## ------------------------------------------------------------------------
repetitive.sequence <- c(rep(1,5), rep(2,5), rep(3,5))
repetitive.df <- data.frame("a"=repetitive.sequence,
                            "b"=repetitive.sequence,
                            "c"=repetitive.sequence)
rle.x <- PLTK::getRleIdx(repetitive.df, col.id="a")
str(rle.x)
 
repetitive.df[rle.x$start.idx[2]:rle.x$end.idx[2],]

## ------------------------------------------------------------------------
PLTK::annotateSegments(PLTK::genDemoData(), PLTK::getGenes())

## ------------------------------------------------------------------------
PLTK::demo.plotScatterLine()

## ------------------------------------------------------------------------
PLTK::demo.plotLikelihoodRatio()

